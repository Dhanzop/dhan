<?



$Cookie='xxxx';



$UserAgent ='xxxx';


